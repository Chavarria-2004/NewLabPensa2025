﻿using System;

class Program 
{
    static void Main() 
    {
        Console.WriteLine("\nIngrese el número correspondiente a su vehículo:");
        Console.WriteLine("1. Bicicleta");
        Console.WriteLine("2. Motocicleta");
        Console.WriteLine("3. Auto");
        Console.WriteLine("4. Camión");
        Console.WriteLine("5. Autobús");

        Console.Write("Selecciona una opción: ");
        string opcion = Console.ReadLine();

        switch (opcion)
        {
            case "1":
                Console.WriteLine("No motorizado");
                break;
            case "2":
                Console.WriteLine("Ligero");
                break;
            case "3":
                Console.WriteLine("Mediano");
                break;
            case "4":
                Console.WriteLine("Pesado");
                break;
            case "5":
                Console.WriteLine("Transporte público");
                break;
            default:
                Console.WriteLine("Opción no válida.");
                break;
        }
    }
}
