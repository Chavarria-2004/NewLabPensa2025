﻿using System;

class Fecha
{
    private int dia, mes, anio;
    private int horaInicio, horaFin;

    public Fecha(int dia, int mes, int anio, int horaInicio, int horaFin)
    {
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
    }

    public int Dia { get => dia; set => dia = value; }
    public int Mes { get => mes; set => mes = value; }
    public int Anio { get => anio; set => anio = value; }
    public int HoraInicio { get => horaInicio; set => horaInicio = value; }
    public int HoraFin { get => horaFin; set => horaFin = value; }

    public bool EsValida()
    {
        if (dia < 1 || dia > 31 || mes < 1 || mes > 12 || anio < 2020 || anio > 2100)
            return false;
        if (horaInicio < 8 || horaFin > 20 || horaInicio >= horaFin)
            return false;
        return true;
    }

    public override string ToString()
    {
        return $"{dia:D2}/{mes:D2}/{anio} de {horaInicio}:00 a {horaFin}:00";
    }

    public bool ConflictaCon(Fecha otra)
    {
        return dia == otra.dia && mes == otra.mes && anio == otra.anio &&
               !(horaFin <= otra.horaInicio || horaInicio >= otra.horaFin);
    }

    public int Comparar(Fecha otra)
    {
        if (anio != otra.anio) return anio.CompareTo(otra.anio);
        if (mes != otra.mes) return mes.CompareTo(otra.mes);
        if (dia != otra.dia) return dia.CompareTo(otra.dia);
        return horaInicio.CompareTo(otra.horaInicio);
    }
}

class ReservaLaboratorio
{
    private string responsable;
    private Fecha fecha;
    private int cantidadComputadoras;

    public ReservaLaboratorio(string responsable, Fecha fecha, int cantidadComputadoras)
    {
        this.responsable = responsable;
        this.fecha = fecha;
        this.cantidadComputadoras = (cantidadComputadoras >= 1 && cantidadComputadoras <= 40) ? cantidadComputadoras : 0;
    }

    public string Responsable { get => responsable; set => responsable = value; }
    public Fecha FechaReserva { get => fecha; set => fecha = value; }
    public int CantidadComputadoras { get => cantidadComputadoras; set => cantidadComputadoras = value; }

    public void MostrarReserva()
    {
        Console.WriteLine($"Responsable: {responsable}");
        Console.WriteLine($"Fecha: {fecha}");
        Console.WriteLine($"Computadoras: {cantidadComputadoras}");
        Console.WriteLine("--------------------------");
    }
}

class AgendaLaboratorio
{
    private ReservaLaboratorio[] reservas = new ReservaLaboratorio[50];
    private int totalReservas = 0;

    public bool AgregarReserva(ReservaLaboratorio nueva)
    {
        if (totalReservas >= 50)
            return false;

        for (int i = 0; i < totalReservas; i++)
        {
            if (reservas[i].FechaReserva.ConflictaCon(nueva.FechaReserva))
                return false;
        }

        reservas[totalReservas++] = nueva;
        return true;
    }

    public void MostrarReservasOrdenadas()
    {
        // Bubble Sort
        for (int i = 0; i < totalReservas - 1; i++)
        {
            for (int j = 0; j < totalReservas - i - 1; j++)
            {
                if (reservas[j].FechaReserva.Comparar(reservas[j + 1].FechaReserva) > 0)
                {
                    var temp = reservas[j];
                    reservas[j] = reservas[j + 1];
                    reservas[j + 1] = temp;
                }
            }
        }

        for (int i = 0; i < totalReservas; i++)
            reservas[i].MostrarReserva();
    }

    public void BuscarPorResponsable(string nombre)
    {
        bool encontrado = false;
        for (int i = 0; i < totalReservas; i++)
        {
            if (reservas[i].Responsable.Equals(nombre, StringComparison.OrdinalIgnoreCase))
            {
                reservas[i].MostrarReserva();
                encontrado = true;
            }
        }

        if (!encontrado)
            Console.WriteLine("No se encontraron reservas para ese responsable.");
    }
}

class Program
{
    static void Main()
    {
        AgendaLaboratorio agenda = new AgendaLaboratorio();
        int opcion;

        do
        {
            Console.WriteLine("\n--- Menú ---");
            Console.WriteLine("1. Agregar nueva reserva");
            Console.WriteLine("2. Mostrar todas las reservas ordenadas por fecha");
            Console.WriteLine("3. Buscar reservas por responsable");
            Console.WriteLine("4. Salir");
            Console.Write("Seleccione una opción: ");
            opcion = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    Console.Write("Nombre del responsable: ");
                    string nombre = Console.ReadLine();
                    Console.Write("Día: "); int dia = int.Parse(Console.ReadLine());
                    Console.Write("Mes: "); int mes = int.Parse(Console.ReadLine());
                    Console.Write("Año: "); int anio = int.Parse(Console.ReadLine());
                    Console.Write("Hora de inicio (8-20): "); int inicio = int.Parse(Console.ReadLine());
                    Console.Write("Hora de fin (8-20): "); int fin = int.Parse(Console.ReadLine());
                    Console.Write("Cantidad de computadoras (1-40): "); int compus = int.Parse(Console.ReadLine());

                    Fecha fecha = new Fecha(dia, mes, anio, inicio, fin);
                    if (!fecha.EsValida())
                    {
                        Console.WriteLine("Fecha u horario inválido.");
                        break;
                    }

                    ReservaLaboratorio reserva = new ReservaLaboratorio(nombre, fecha, compus);
                    if (reserva.CantidadComputadoras == 0)
                    {
                        Console.WriteLine("Cantidad de computadoras inválida.");
                        break;
                    }

                    if (agenda.AgregarReserva(reserva))
                        Console.WriteLine("Reserva agregada exitosamente.");
                    else
                        Console.WriteLine("Error: conflicto de horario o capacidad llena.");
                    break;

                case 2:
                    agenda.MostrarReservasOrdenadas();
                    break;

                case 3:
                    Console.Write("Nombre del responsable a buscar: ");
                    string buscado = Console.ReadLine();
                    agenda.BuscarPorResponsable(buscado);
                    break;

                case 4:
                    Console.WriteLine("Saliendo del sistema...");
                    break;

                default:
                    Console.WriteLine("Opción inválida.");
                    break;
            }

        } while (opcion != 4);
    }
}