﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Ejercicio1_Vector();
        Ejercicio2_Inventario();
    }

    // Ejercicio1 anejo de vectores
    static void Ejercicio1_Vector()
    {
        int[] vector = new int[100]; 
        int cantidad = 0;  
        bool continuar = true;

        while (continuar)
        {
            Console.WriteLine("\nMenú - Manejo de Vectores");
            Console.WriteLine("1. Introducir valores");
            Console.WriteLine("2. Leer datos");
            Console.WriteLine("3. Desplegar los datos");
            Console.WriteLine("4. Buscar un dato");
            Console.WriteLine("5. Actualizar un dato");
            Console.WriteLine("6. Ordenar los valores");
            Console.WriteLine("7. Salir");
            Console.Write("Seleccione una opción: ");
            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    Console.Write("¿Cuántos valores desea ingresar? ");
                    cantidad = int.Parse(Console.ReadLine());
                    for (int i = 0; i < cantidad; i++)
                    {
                        Console.Write($"Ingrese el valor #{i + 1}: ");
                        vector[i] = int.Parse(Console.ReadLine());
                    }
                    break;
                case "2":
                    Console.WriteLine("Valores actuales en el vector:");
                    for (int i = 0; i < cantidad; i++)
                    {
                        Console.WriteLine($"Posición {i}: {vector[i]}");
                    }
                    break;
                case "3":
                    Console.WriteLine("Todos los valores del vector:");
                    for (int i = 0; i < cantidad; i++)
                    {
                        Console.WriteLine(vector[i]);
                    }
                    break;
                case "4":
                    Console.Write("Ingrese el valor a buscar: ");
                    int buscar = int.Parse(Console.ReadLine());
                    int index = Array.IndexOf(vector, buscar);
                    if (index != -1)
                        Console.WriteLine($"Valor encontrado en la posición {index}");
                    else
                        Console.WriteLine("Valor no encontrado.");
                    break;
                case "5":
                    Console.Write("Ingrese la posición a actualizar: ");
                    int pos = int.Parse(Console.ReadLine());
                    if (pos >= 0 && pos < cantidad)
                    {
                        Console.Write("Nuevo valor: ");
                        vector[pos] = int.Parse(Console.ReadLine());
                        Console.WriteLine("Dato actualizado.");
                    }
                    else
                    {
                        Console.WriteLine("Posición inválida.");
                    }
                    break;
                case "6":
                    Array.Sort(vector, 0, cantidad);
                    Console.WriteLine("Vector ordenado de menor a mayor.");
                    break;
                case "7":
                    continuar = false;
                    break;
                default:
                    Console.WriteLine("Opción inválida.");
                    break;
            }
        }
    }

    // Ejercicio2 estión de Inventario con Estructuras
    struct Producto
    {
        public string Nombre;
        public string Codigo;
        public double Precio;
        public int Cantidad;
    }

    static void Ejercicio2_Inventario()
    {
        Producto[] inventario = new Producto[100]; // Tamaño máximo del inventario
        int cantidadProductos = 0;
        bool seguir = true;

        while (seguir)
        {
            Console.WriteLine("\nMenú - Gestión de Inventario");
            Console.WriteLine("1. Agregar producto");
            Console.WriteLine("2. Modificar precio de un producto");
            Console.WriteLine("3. Mostrar productos");
            Console.WriteLine("4. Calcular valor total del inventario");
            Console.WriteLine("5. Salir");
            Console.Write("Seleccione una opción: ");
            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    Producto p = new Producto();
                    Console.Write("Nombre del producto: ");
                    p.Nombre = Console.ReadLine();
                    Console.Write("Código del producto: ");
                    p.Codigo = Console.ReadLine();
                    Console.Write("Precio del producto: ");
                    p.Precio = double.Parse(Console.ReadLine());
                    Console.Write("Cantidad del producto: ");
                    p.Cantidad = int.Parse(Console.ReadLine());
                    inventario[cantidadProductos] = p;
                    cantidadProductos++;
                    Console.WriteLine("Producto agregado.");
                    break;
                case "2":
                    Console.Write("Ingrese el código del producto a modificar: ");
                    string codBuscar = Console.ReadLine();
                    bool encontrado = false;
                    for (int i = 0; i < cantidadProductos; i++)
                    {
                        if (inventario[i].Codigo == codBuscar)
                        {
                            Console.Write("Nuevo precio: ");
                            inventario[i].Precio = double.Parse(Console.ReadLine());
                            encontrado = true;
                            Console.WriteLine("Precio actualizado.");
                            break;
                        }
                    }
                    if (!encontrado)
                        Console.WriteLine("Producto no encontrado.");
                    break;
                case "3":
                    Console.WriteLine("Productos en el inventario:");
                    for (int i = 0; i < cantidadProductos; i++)
                    {
                        Console.WriteLine($"Nombre: {inventario[i].Nombre}, Código: {inventario[i].Codigo}, Precio: {inventario[i].Precio}, Cantidad: {inventario[i].Cantidad}");
                    }
                    break;
                case "4":
                    double total = 0;
                    for (int i = 0; i < cantidadProductos; i++)
                    {
                        total += inventario[i].Precio * inventario[i].Cantidad;
                    }
                    Console.WriteLine($"Valor total del inventario: {total}");
                    break;
                case "5":
                    seguir = false;
                    break;
                default:
                    Console.WriteLine("Opción inválida.");
                    break;
            }
        }
    }
}
