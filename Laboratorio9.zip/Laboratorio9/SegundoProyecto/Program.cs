﻿using System;

class Program {
    static void Main() {
        /*/ Ejercicio 1: Descuento en tienda de ropa
        Console.Write("Ingrese el monto de la compra: Quetzales ");
        double monto = Convert.ToDouble(Console.ReadLine());

        double descuento = 0;
        if (monto >= 100) {
            descuento = monto * 0.20;
        } else if (monto >= 50) {
            descuento = monto * 0.10;
        }

        double totalPagar = monto - descuento;
        Console.WriteLine("Descuento aplicado: Quetzales " + descuento);
        Console.WriteLine("Total a pagar: Quetzales " + totalPagar + "\n");

        // Ejercicio 2: Acceso a discoteca
        Console.Write("Ingrese su edad: ");
        int edad = Convert.ToInt32(Console.ReadLine());

        if (edad >= 18) {
            Console.WriteLine("Acceso permitido.\n");
        } else {
            Console.WriteLine("Acceso denegado.\n");
        }

        // Ejercicio 3: Operaciones con dos números
        Console.Write("Ingrese el primer número: ");
        int num1 = Convert.ToInt32(Console.ReadLine());
        Console.Write("Ingrese el segundo número: ");
        int num2 = Convert.ToInt32(Console.ReadLine());

        int resultado;
        if (num1 == num2) {
            resultado = num1 * num2;
            Console.WriteLine("Resultado: " + resultado + "\n");
        } else if (num1 > num2) {
            resultado = num1 - num2;
            Console.WriteLine("Resultado: " + resultado + "\n");
        } else {
            resultado = num1 + num2;
            Console.WriteLine("Resultado: " + resultado + "\n");
        }*/

        // Ejercicio 4: Pago de vendedor de autos
        Console.Write("Ingrese el nombre del vendedor: ");
        string vendedor = Console.ReadLine();
        Console.Write("Ingrese la cantidad de autos vendidos: ");
        int autosVendidos = Convert.ToInt32(Console.ReadLine());

        double pagoBase = 350;
        double comision = autosVendidos * 15;
        double bono = autosVendidos > 15 ? 40 : 0;
        double sueldoBruto = pagoBase + comision + bono;
        double impuesto = sueldoBruto * 0.05;
        double sueldoNeto = sueldoBruto - impuesto;

        Console.WriteLine("\nResumen de pago:");
        Console.WriteLine("Vendedor: " + vendedor);
        Console.WriteLine("Sueldo bruto: Q" + sueldoBruto);
        Console.WriteLine("Impuesto (5%): Q" + impuesto);
        Console.WriteLine("Sueldo neto: Q" + sueldoNeto);
    }
}