﻿using System;

class Program 
{
    static void Main() 
    {
        // Programa 1: Clasificación por edad
        Console.Write("Ingrese su edad: ");
        int age = int.Parse(Console.ReadLine());

        if (age < 12)
        {
            Console.WriteLine("Niño");
        }
        else if (age >= 12 && age <= 17)
        {
            Console.WriteLine("Adolescente");
        }
        else if (age >= 18 && age <= 64)
        {
            Console.WriteLine("Adulto");
        }
        else
        {
            Console.WriteLine("Adulto mayor");
        }

        Console.WriteLine("\n--------------------------------\n");

        // Programa 2: Clasificación por calificación
        Console.Write("Ingrese su calificación: ");
        int grade = int.Parse(Console.ReadLine());

        if (grade >= 0 && grade <= 59)
        {
            Console.WriteLine("Reprobado");
        }
        else if (grade >= 60 && grade <= 79)
        {
            Console.WriteLine("Aprobado");
        }
        else if (grade >= 80 && grade <= 89)
        {
            Console.WriteLine("Notable");
        }
        else if (grade >= 90 && grade <= 100)
        {
            Console.WriteLine("Excelente");
        }
        else
        {
            Console.WriteLine("Calificación inválida");
        }

        Console.WriteLine("\n--------------------------------\n");

        // Programa 3: Tarifa de transporte público
        const double tarifaNormal = 10.00;
        double tarifaFinal = tarifaNormal;

        Console.WriteLine("Seleccione su categoría:");
        Console.WriteLine("1. Adulto (tarifa normal)");
        Console.WriteLine("2. Estudiante (descuento del 50%)");
        Console.WriteLine("3. Adulto mayor (descuento del 30%)");
        Console.WriteLine("4. Niño (gratis si es menor de 5 años, 50% de descuento si es entre 5 y 12)");
        Console.WriteLine("5. Salir del programa");

        Console.Write("Ingrese una opción: ");
        string option = Console.ReadLine();

        switch (option)
        {
            case "1":
                Console.WriteLine($"Debe pagar: Q{tarifaNormal}");
                break;
            case "2":
                tarifaFinal *= 0.5;
                Console.WriteLine($"Debe pagar: Q{tarifaFinal}");
                break;
            case "3":
                tarifaFinal *= 0.7;
                Console.WriteLine($"Debe pagar: Q{tarifaFinal}");
                break;
            case "4":
                Console.Write("Ingrese la edad del niño: ");
                int childAge = int.Parse(Console.ReadLine());

                if (childAge < 5)
                {
                    Console.WriteLine("Viaje gratis.");
                }
                else if (childAge >= 5 && childAge <= 12)
                {
                    tarifaFinal *= 0.5;
                    Console.WriteLine($"Debe pagar: Q{tarifaFinal}");
                }
                else
                {
                    Console.WriteLine("Debe pagar tarifa normal.");
                }
                break;
            case "5":
                Console.WriteLine("Saliendo del programa...");
                return;
            default:
                Console.WriteLine("Opción no válida.");
                break;
        }
    }
}
