﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Ejercicio 1: DNI
        Ejercicio1_DNI();

        // Ejercicio 2: Validación de contraseña con intentos
        Ejercicio2_Contraseña();

        // Ejercicio 3: Simulación de cajero automático
        Ejercicio3_CajeroAutomatico();
    }

    // Ejercicio1 DNI
    static void Ejercicio1_DNI()
    {
        Console.Write("Ingrese su número de DNI: ");
        int dni = int.Parse(Console.ReadLine());

        Console.Write("Ingrese la letra de su DNI: ");
        char letra = char.ToUpper(Console.ReadLine()[0]);

        if (CompruebaLetraDni(dni, letra))
        {
            Console.WriteLine("¡Bienvenido!");
        }
        else
        {
            Console.WriteLine("Ha cometido Ud. un error.");
        }
    }

    static char LetraDni(int dni)
    {
        char[] letras = { 'T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E' };
        return letras[dni % 23];
    }

    static bool CompruebaLetraDni(int dni, char letra)
    {
        return LetraDni(dni) == letra;
    }

    // Ejercicio2 Validación de contraseña con intentos
    static void Ejercicio2_Contraseña()
    {
        string contraseñaCorrecta = "Contraseña123";
        SolicitarContraseña(contraseñaCorrecta);
    }

    static bool ValidarFormato(string contraseña)
    {
        if (contraseña.Length >= 8 && contraseña.Any(char.IsUpper) && contraseña.Any(char.IsDigit))
        {
            return true;
        }
        return false;
    }

    static void SolicitarContraseña(string contraseñaCorrecta)
    {
        int intentos = 0;
        bool accesoPermitido = false;

        while (intentos < 3 && !accesoPermitido)
        {
            Console.Write("Ingrese la contraseña: ");
            string contraseña = Console.ReadLine();

            if (ValidarFormato(contraseña))
            {
                if (contraseña == contraseñaCorrecta)
                {
                    Console.WriteLine("Acceso permitido");
                    accesoPermitido = true;
                }
                else
                {
                    Console.WriteLine("Contraseña incorrecta.");
                }
            }
            else
            {
                Console.WriteLine("La contraseña debe tener al menos 8 caracteres, una mayúscula y un número.");
            }

            intentos++;
        }

        if (!accesoPermitido)
        {
            Console.WriteLine("Acceso denegado.");
        }
    }

    // Ejercicio 3 mulación de cajero automático
    static void Ejercicio3_CajeroAutomatico()
    {
        double saldo = 1000;
        bool continuar = true;

        while (continuar)
        {
            MostrarMenu();
            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    saldo = ConsultarSaldo(saldo);
                    break;
                case "2":
                    saldo = Retirar(saldo);
                    break;
                case "3":
                    saldo = Depositar(saldo);
                    break;
                case "4":
                    continuar = false;
                    break;
                default:
                    Console.WriteLine("Opción no válida.");
                    break;
            }
        }
    }

    static void MostrarMenu()
    {
        Console.WriteLine("\nCajero Automático");
        Console.WriteLine("1. Consultar saldo");
        Console.WriteLine("2. Retirar dinero");
        Console.WriteLine("3. Depositar dinero");
        Console.WriteLine("4. Salir");
        Console.Write("Seleccione una opción: ");
    }

    static double ConsultarSaldo(double saldo)
    {
        Console.WriteLine($"Saldo disponible: {saldo}€");
        return saldo;
    }

    static double Depositar(double saldo)
    {
        Console.Write("Ingrese la cantidad a depositar: ");
        double cantidad = double.Parse(Console.ReadLine());
        saldo += cantidad;
        Console.WriteLine($"Nuevo saldo: {saldo}€");
        return saldo;
    }

    static double Retirar(double saldo)
    {
        Console.Write("Ingrese la cantidad a retirar: ");
        double cantidad = double.Parse(Console.ReadLine());

        if (cantidad <= saldo)
        {
            saldo -= cantidad;
            Console.WriteLine($"Nuevo saldo: {saldo}€");
        }
        else
        {
            Console.WriteLine("No tiene suficiente saldo.");
        }

        return saldo;
    }
}
