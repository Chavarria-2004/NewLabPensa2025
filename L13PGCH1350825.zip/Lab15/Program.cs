﻿using System;
using System.Text.RegularExpressions;

namespace L13_JP12345 // Cambia esto por tus datos reales
{
    class Program
    {
        static void Main(string[] args)
        {
        }


        // Ejercicio 1: DNI

        static void Ejercicio1_DNI()
        {
            Console.Write("Ingrese el número de DNI: ");
            int numeroDNI = int.Parse(Console.ReadLine());

            Console.Write("Ingrese la letra del DNI: ");
            char letraUsuario = char.ToUpper(Console.ReadKey().KeyChar);
            Console.WriteLine();

            if (CompruebaLetraDNI(numeroDNI, letraUsuario))
                Console.WriteLine("Bienvenido");
            else
                Console.WriteLine("Ha cometido Ud. un error");
        }

        static char LetraDNI(int numero)
        {
            string letras = "TRWAGMYFPDXBNJZSQVHLCKE";
            return letras[numero % 23];
        }

        static bool CompruebaLetraDNI(int numero, char letra)
        {
            return LetraDNI(numero) == letra;
        }

        // Ejercicio 2: Validación de contraseña

        static void Ejercicio2_Contrasena()
        {
            string contrasenaCorrecta = "Clave123";

            SolicitarContraseña(contrasenaCorrecta);
        }

        static void SolicitarContraseña(string contraseñaCorrecta)
        {
            int intentos = 0;
            while (intentos < 3)
            {
                Console.Write("Ingrese su contraseña: ");
                string input = Console.ReadLine();

                if (!ValidarFormato(input))
                {
                    Console.WriteLine("Formato de contraseña inválido. Debe tener al menos 8 caracteres, una mayúscula y un número.");
                    intentos++;
                    continue;
                }

                if (input == contraseñaCorrecta)
                {
                    Console.WriteLine("Acceso permitido");
                    return;
                }
                else
                {
                    Console.WriteLine("Contraseña incorrecta");
                    intentos++;
                }
            }

            Console.WriteLine("Acceso denegado");
        }

        static bool ValidarFormato(string contraseña)
        {
            return contraseña.Length >= 8 &&
                   Regex.IsMatch(contraseña, @"[A-Z]") &&
                   Regex.IsMatch(contraseña, @"[0-9]");
        }


        // Ejercicio 3: Cajero automático

        static void Ejercicio3_Cajero()
        {
            double saldo = 1000;
            bool continuar = true;

            while (continuar)
            {
                MostrarMenu();
                Console.Write("Seleccione una opción: ");
                string opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        Console.WriteLine($"Saldo actual: {ConsultarSaldo(saldo)}");
                        break;
                    case "2":
                        Console.Write("Ingrese cantidad a depositar: ");
                        double deposito = double.Parse(Console.ReadLine());
                        saldo = Depositar(saldo, deposito);
                        break;
                    case "3":
                        Console.Write("Ingrese cantidad a retirar: ");
                        double retiro = double.Parse(Console.ReadLine());
                        saldo = Retirar(saldo, retiro);
                        break;
                    case "4":
                        continuar = false;
                        break;
                    default:
                        Console.WriteLine("Opción inválida");
                        break;
                }
            }
        }

        static void MostrarMenu()
        {
            Console.WriteLine("\n--- Cajero Automático ---");
            Console.WriteLine("1. Consultar saldo");
            Console.WriteLine("2. Depositar dinero");
            Console.WriteLine("3. Retirar dinero");
            Console.WriteLine("4. Salir");
        }

        static double ConsultarSaldo(double saldo)
        {
            return saldo;
        }

        static double Depositar(double saldo, double cantidad)
        {
            if (cantidad <= 0)
            {
                Console.WriteLine("Cantidad inválida");
                return saldo;
            }

            saldo += cantidad;
            Console.WriteLine("Depósito exitoso.");
            return saldo;
        }

        static double Retirar(double saldo, double cantidad)
        {
            if (cantidad <= 0)
            {
                Console.WriteLine("Cantidad inválida");
            }
            else if (cantidad > saldo)
            {
                Console.WriteLine("Fondos insuficientes.");
            }
            else
            {
                saldo -= cantidad;
                Console.WriteLine("Retiro exitoso.");
            }

            return saldo;
        }
    }
}
