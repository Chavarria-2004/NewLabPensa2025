﻿using System;

class Program
{
    static void Main()
    {
        /* Ejercicio 1:  Invertir una palabra
        Console.Write("Ingresa una palabra: ");
        string palabra = Console.ReadLine();

        string invertida = "";
        for (int i = palabra.Length - 1; i >= 0; i--)
        {
            invertida += palabra[i];
        }

        Console.WriteLine("Palabra invertida: " + invertida);

        if (palabra.ToLower() == invertida.ToLower())
        {
            Console.WriteLine("La palabra es un palíndromo.");
        }
        else
        {
            Console.WriteLine("La palabra no es un palíndromo.");
        }
           Ejercicio 2: Contar cuántas vocales tiene una frase 
        Console.Write("Ingresa una frase: ");
        string frase = Console.ReadLine().ToLower();

        int contadorA = 0, contadorE = 0, contadorI = 0, contadorO = 0, contadorU = 0;

        foreach (char letra in frase)
        {
            switch (letra)
            {
                case 'a': contadorA++; break;
                case 'e': contadorE++; break;
                case 'i': contadorI++; break;
                case 'o': contadorO++; break;
                case 'u': contadorU++; break;
            }
        }

        Console.WriteLine($"Número de vocales: {contadorA + contadorE + contadorI + contadorO + contadorU}");
        Console.WriteLine($"A: {contadorA}, E: {contadorE}, I: {contadorI}, O: {contadorO}, U: {contadorU}");
        Ejercicio 3: Reemplazar caracteres en una cadena */
        Console.Write("Ingresa una oracion: ");
        string fraseModificable = Console.ReadLine();

        Console.Write("Palabra que quiere cambiar: ");
        string original = Console.ReadLine();

        Console.Write("Nueva palabra para cambiar: ");
        string nuevo = Console.ReadLine();

        string resultado = fraseModificable.Replace(original, nuevo);

        Console.WriteLine("Oracion modificada: " + resultado);
    }
}          